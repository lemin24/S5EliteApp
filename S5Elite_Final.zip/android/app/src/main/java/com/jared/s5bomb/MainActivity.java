package com.jared.s5bomb;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
